import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { API_BASE } from './config';

function Home() {
  const [tema, setTema] = useState('');
  const [resposta, setResposta] = useState('');

  const handleSearch = async () => {
    const res = await fetch(`${API_BASE}/explain`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tema })
    });
    const data = await res.json();
    setResposta(data.result || 'Nenhuma resposta');
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Estudo Inteligente</h1>
      <input 
        type="text" 
        placeholder="Digite um tema" 
        value={tema} 
        onChange={e => setTema(e.target.value)} 
      />
      <button onClick={handleSearch}>Pesquisar</button>
      <div style={{ marginTop: '20px' }}>{resposta}</div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
    </Router>
  );
}
